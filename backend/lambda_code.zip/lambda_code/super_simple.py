def handler(event, context):
    return {
        'statusCode': 200,
        'body': '{"message": "Função super simples funcionando!"}'
    }
